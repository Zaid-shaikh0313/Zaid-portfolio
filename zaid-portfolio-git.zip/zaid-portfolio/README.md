# Zaid Shaikh — Portfolio

Personal portfolio site for Zaid Shaikh, Senior Data Engineer based in Berlin, Germany.

Built with a dark, console/pipeline-themed design — an animated data pipeline strip (Ingest → Transform → Serve → Govern) as the signature element, reflecting a real lakehouse architecture.

## Stack

- [Next.js](https://nextjs.org) (App Router)
- TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals, pipeline animation)

## Sections

- Hero with animated pipeline status strip
- Experience (SoftPixel Solutions, Ziff Davis, XDBS)
- Projects (Databricks Lakehouse, E-Commerce Analytics, Enterprise RAG Assistant)
- Skills, grouped by category
- Education & certifications
- Contact

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy

Deployed on [Vercel](https://vercel.com). Push to `main` to trigger a deploy if the Vercel GitHub integration is connected, or run:

```bash
npx vercel
```
